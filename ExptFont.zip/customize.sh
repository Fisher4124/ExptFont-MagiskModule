ui_print "




—— 刷入时间$(date '+%g-%m-%d %H:%M:%S')


—— 面具版本$MAGISK_VER_CODE


—— 面具代号$MAGISK_VER




"
echo "id=实验字库0.1
name=实验字库0.1
version=0.1
versionCode=0.1
author=fisher4124@qq.com
description=实验字库0.1 [刷入时间：$(date '+%g-%m-%d %H:%M:%S')]" > $MODPATH/module.prop